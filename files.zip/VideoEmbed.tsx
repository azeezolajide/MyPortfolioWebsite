'use client';

import Image from 'next/image';
import { useState } from 'react';
import { parseVideo, posterFor } from '@/lib/video';

type Props = {
  url?: string;
  poster?: string;
  title: string;
  /** Shown when no URL has been added yet. */
  emptyHint?: string;
};

/**
 * Nothing loads until the visitor presses play — no third-party iframe, no
 * autoplaying video, no wasted bandwidth on a page full of thumbnails.
 */
export default function VideoEmbed({ url, poster, title, emptyHint }: Props) {
  const [playing, setPlaying] = useState(false);
  const source = parseVideo(url);
  const still = posterFor(poster, url);

  if (source.kind === 'none') {
    return (
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-dashed border-line bg-surface">
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 px-6 text-center">
          <PlayMark muted />
          <p className="max-w-[38ch] text-sm text-muted">
            {emptyHint ?? 'Add a YouTube, Vimeo or .mp4 URL to show your video here.'}
          </p>
        </div>
      </div>
    );
  }

  if (!playing) {
    return (
      <button
        type="button"
        onClick={() => setPlaying(true)}
        aria-label={`Play ${title}`}
        className="group relative block aspect-video w-full overflow-hidden rounded-xl border border-line bg-surface"
      >
        {still && (
          <Image
            src={still}
            alt=""
            fill
            sizes="(max-width: 768px) 100vw, 900px"
            className="object-cover opacity-80 transition duration-700 ease-cut group-hover:scale-[1.03] group-hover:opacity-100"
          />
        )}
        <span className="absolute inset-0 bg-gradient-to-t from-base/70 to-transparent" />
        <span className="absolute inset-0 flex items-center justify-center">
          <PlayMark />
        </span>
      </button>
    );
  }

  if (source.kind === 'file') {
    return (
      // eslint-disable-next-line jsx-a11y/media-has-caption
      <video
        src={source.src}
        poster={still ?? undefined}
        controls
        autoPlay
        playsInline
        className="aspect-video w-full rounded-xl border border-line bg-black"
      />
    );
  }

  return (
    <div className="aspect-video w-full overflow-hidden rounded-xl border border-line bg-black">
      <iframe
        src={`${source.embed}${source.embed.includes('?') ? '&' : '?'}autoplay=1`}
        title={title}
        loading="lazy"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        className="h-full w-full"
      />
    </div>
  );
}

function PlayMark({ muted = false }: { muted?: boolean }) {
  return (
    <span
      className={`flex h-16 w-16 items-center justify-center rounded-full border transition duration-300 ease-cut ${
        muted
          ? 'border-line text-muted'
          : 'border-accent bg-accent/10 text-accent group-hover:bg-accent group-hover:text-base'
      }`}
    >
      <svg width="16" height="18" viewBox="0 0 16 18" fill="currentColor" aria-hidden="true">
        <path d="M0 0l16 9L0 18z" />
      </svg>
    </span>
  );
}
