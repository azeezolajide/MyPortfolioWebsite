import Image from 'next/image';
import Link from 'next/link';
import type { Project } from '@/data/projects';
import { posterFor } from '@/lib/video';

export default function ProjectCard({ project }: { project: Project }) {
  if (project.placeholder) return <PlaceholderCard category={project.category} />;

  const still = posterFor(project.thumbnail, project.video);

  return (
    <article className="group">
      <Link href={`/work/${project.slug}`} className="block">
        <div className="relative aspect-video overflow-hidden rounded-lg border border-line bg-surface">
          {still ? (
            <Image
              src={still}
              alt={`Still frame from ${project.title}`}
              fill
              loading="lazy"
              sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
              className="object-cover transition duration-[900ms] ease-cut group-hover:scale-[1.04]"
            />
          ) : (
            <div className="absolute inset-0 bg-[radial-gradient(120%_120%_at_20%_0%,#1a1d21,#0b0c0e)]" />
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-base/80 via-base/10 to-transparent opacity-70 transition-opacity duration-500 group-hover:opacity-90" />

          {project.duration && (
            <span className="tc absolute bottom-3 right-3 rounded bg-base/80 px-2 py-1 text-ink">
              {project.duration}
            </span>
          )}

          <span className="absolute inset-x-0 bottom-0 h-px origin-left scale-x-0 bg-accent transition-transform duration-500 ease-cut group-hover:scale-x-100" />
        </div>

        <div className="mt-4 flex items-baseline justify-between gap-4">
          <h3 className="text-lg font-semibold tracking-tight transition-colors duration-300 group-hover:text-accent">
            {project.title}
          </h3>
          <span className="tc shrink-0">{project.category}</span>
        </div>
      </Link>

      {project.description && (
        <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">{project.description}</p>
      )}

      <p className="mt-3 text-sm text-muted">
        {project.client && !project.client.startsWith('YOUR_') && <span>{project.client}</span>}
        {project.client && project.year && <span className="px-2 text-line">/</span>}
        {project.year && <span>{project.year}</span>}
      </p>
    </article>
  );
}

function PlaceholderCard({ category }: { category: string }) {
  return (
    <article aria-label={`Empty ${category} slot`}>
      <div className="relative flex aspect-video items-center justify-center rounded-lg border border-dashed border-line bg-surface/40">
        <span className="tc text-cool">{category}</span>
      </div>
      <div className="mt-4 flex items-baseline justify-between gap-4">
        <h3 className="text-lg font-semibold tracking-tight text-muted">Open slot</h3>
        <span className="tc shrink-0">—:—</span>
      </div>
      <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">
        Add this project in <code className="text-cool">src/data/projects.ts</code>.
      </p>
    </article>
  );
}
