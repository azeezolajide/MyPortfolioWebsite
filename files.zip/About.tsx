import Link from 'next/link';
import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

export default function About() {
  return (
    <section id="about" className="scroll-mt-20 border-t border-line py-24 md:py-32">
      <div className="shell grid gap-12 md:grid-cols-[auto_1fr] md:gap-20">
        <p className="tc md:pt-3">S01 — About</p>

        <div>
          <h2 className="display max-w-[16ch] text-[clamp(2rem,5.4vw,4rem)]">
            <Reveal variant="wipe">{site.about.heading}</Reveal>
          </h2>

          <div className="mt-8 max-w-prose space-y-5 text-base leading-relaxed text-muted">
            {site.about.body.map((p) => (
              <Reveal key={p.slice(0, 24)}>
                <p>{p}</p>
              </Reveal>
            ))}
          </div>

          <Reveal delay={0.1}>
            <Link href="/#contact" className="btn-ghost mt-10">
              More about me
            </Link>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
