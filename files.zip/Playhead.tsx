'use client';

import { useEffect, useState } from 'react';

/**
 * A scrub bar pinned to the bottom of the viewport. Scroll position is the
 * playhead; the readout is a real timecode derived from page progress, so the
 * page reads like a sequence in an NLE. Decorative only — hidden from AT.
 */
export default function Playhead() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let frame = 0;

    const update = () => {
      frame = 0;
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(max > 0 ? Math.min(1, Math.max(0, window.scrollY / max)) : 0);
    };

    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };

    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (frame) cancelAnimationFrame(frame);
    };
  }, []);

  // A nominal 90-second "sequence" mapped across the full page.
  const total = 90;
  const seconds = progress * total;
  const mm = String(Math.floor(seconds / 60)).padStart(2, '0');
  const ss = String(Math.floor(seconds % 60)).padStart(2, '0');
  const ff = String(Math.floor((seconds % 1) * 24)).padStart(2, '0');

  return (
    <div
      aria-hidden="true"
      className="pointer-events-none fixed inset-x-0 bottom-0 z-50 hidden select-none md:block"
    >
      <div className="flex items-end gap-4 px-6 pb-4">
        <span className="tc text-ink/70">
          00:{mm}:{ss}:{ff}
        </span>
        <div className="relative h-px flex-1 bg-line">
          <div
            className="absolute inset-y-0 left-0 bg-accent"
            style={{ width: `${progress * 100}%` }}
          />
          <div
            className="absolute -top-[5px] h-[11px] w-[2px] bg-accent"
            style={{ left: `${progress * 100}%` }}
          />
        </div>
        <span className="tc text-muted">00:01:30:00</span>
      </div>
    </div>
  );
}
