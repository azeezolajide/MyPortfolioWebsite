import Link from 'next/link';
import Reveal from '@/components/Reveal';
import WorkGrid from '@/components/WorkGrid';
import { projects } from '@/data/projects';

export default function Work() {
  return (
    <section id="work" className="scroll-mt-20 border-t border-line py-24 md:py-32">
      <div className="shell">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div>
            <p className="tc mb-6">S02 — Work</p>
            <h2 className="display text-[clamp(2.2rem,7vw,5rem)]">
              <Reveal variant="wipe">Selected work</Reveal>
            </h2>
          </div>
          <Link href="/work" className="text-sm text-muted transition-colors hover:text-accent">
            All projects
          </Link>
        </div>

        <Reveal delay={0.06}>
          <p className="mt-6 max-w-prose text-base leading-relaxed text-muted">
            A selection of video editing, motion graphics, brand animation, and visual storytelling
            projects.
          </p>
        </Reveal>

        <div className="mt-12">
          <WorkGrid projects={projects} />
        </div>
      </div>
    </section>
  );
}
