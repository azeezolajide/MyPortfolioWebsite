'use client';

import Link from 'next/link';
import { motion, useReducedMotion } from 'framer-motion';
import { site } from '@/data/site';

export default function Hero() {
  const reduced = useReducedMotion();

  // One orchestrated entrance for the whole hero, then the page goes quiet.
  const rise = (delay: number) =>
    reduced
      ? {}
      : {
          initial: { y: '105%' },
          animate: { y: '0%' },
          transition: { duration: 0.95, delay, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
        };

  const fade = (delay: number) =>
    reduced
      ? {}
      : {
          initial: { opacity: 0, y: 12 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.7, delay, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
        };

  return (
    <section className="relative flex min-h-[100svh] flex-col justify-end overflow-hidden pb-20 pt-32 sm:pb-24">
      {/* A single cold key light bleeding in from the top right. */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-1/4 -top-1/3 h-[70vh] w-[70vw] rounded-full bg-[radial-gradient(circle,rgba(126,147,166,0.16),transparent_62%)]"
      />

      <div className="shell relative">
        <motion.p {...fade(0.1)} className="mb-10 flex items-center gap-3">
          <span className="h-1.5 w-1.5 rounded-full bg-accent animate-pulseDot" />
          <span className="tc text-ink/80">{site.availability}</span>
        </motion.p>

        <h1 className="display text-[clamp(2.9rem,12.2vw,10.5rem)]">
          <span className="block overflow-hidden">
            <motion.span className="block" {...rise(0.15)}>
              {site.hero.line1}
            </motion.span>
          </span>
          <span className="block overflow-hidden text-cool">
            <motion.span className="block" {...rise(0.25)}>
              {site.hero.line2}
            </motion.span>
          </span>
        </h1>

        <div className="mt-12 grid gap-10 border-t border-line pt-8 md:grid-cols-[1fr_auto] md:items-end">
          <motion.p {...fade(0.5)} className="max-w-prose text-base leading-relaxed text-muted">
            {site.hero.intro}
          </motion.p>

          <motion.div {...fade(0.6)} className="flex flex-wrap gap-3">
            <Link href="/work" className="btn-accent">
              View my work
            </Link>
            <Link href="/#contact" className="btn-ghost">
              Let’s work together
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
