/**
 * ─────────────────────────────────────────────────────────────
 *  EDIT THIS FILE FIRST.
 *  Everything about you — name, email, socials, copy, services,
 *  skills and tools — lives here. No component needs touching.
 *  Anything still written as YOUR_SOMETHING is a placeholder.
 * ─────────────────────────────────────────────────────────────
 */

export const site = {
  brand: 'Vxmedia_edit',
  title: 'Video Editor & Motion Graphics Designer',
  longTitle: 'Creative Video Editor | Motion Designer | Visual Storyteller',

  /** Used for canonical URLs, sitemap and social cards. */
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'https://vxmediaedit.vercel.app',

  availability: 'Available for freelance & remote work',

  seo: {
    title: 'Vxmedia_edit — Video Editor & Motion Graphics Designer',
    description:
      'Vxmedia_edit is a Video Editor and Motion Graphics Designer creating engaging visual stories, motion graphics, brand animations, and digital content.',
    /** Leave empty to use the auto-generated card. Or drop a 1200x630
     *  image in /public and point at it, e.g. '/og.jpg'. */
    ogImage: '',
    keywords: [
      'video editor',
      'motion graphics designer',
      'brand animation',
      'visual storytelling',
      'short form video editor',
      'explainer video',
    ],
  },

  /** Replace every placeholder below with your real details. */
  contact: {
    email: 'YOUR_EMAIL',
    location: 'YOUR_LOCATION',
    /** Set to null to hide a link entirely. */
    socials: [
      { label: 'LinkedIn', href: 'YOUR_LINKEDIN' },
      { label: 'Instagram', href: 'YOUR_INSTAGRAM' },
      { label: 'X', href: 'YOUR_X_PROFILE' },
      { label: 'YouTube', href: 'YOUR_YOUTUBE' },
    ] as { label: string; href: string }[],
  },

  nav: [
    { label: 'Home', href: '/' },
    { label: 'Work', href: '/work' },
    { label: 'About', href: '/#about' },
    { label: 'Services', href: '/#services' },
    { label: 'Contact', href: '/#contact' },
  ],

  hero: {
    line1: 'Video Editor',
    line2: '& Motion Designer',
    intro:
      'I turn ideas, raw footage, and concepts into engaging visual stories through editing, motion graphics, and creative storytelling.',
  },

  about: {
    heading: 'I turn ideas into visual stories.',
    body: [
      'I’m a Video Editor and Motion Graphics Designer focused on creating engaging visual content for brands, businesses, creators, and digital products.',
      'My work combines editing, motion design, storytelling, typography, sound, and visual composition to create content that communicates clearly and keeps people watching.',
    ],
  },

  /**
   * Your introduction video. Paste a YouTube, Vimeo or .mp4 URL.
   * Leave it as YOUR_INTRO_VIDEO and a placeholder frame is shown instead.
   */
  introVideo: {
    heading: 'Let’s create something worth watching.',
    body: 'Watch my introduction to learn more about my creative approach, skills, and the kind of work I create.',
    url: 'YOUR_INTRO_VIDEO',
    poster: '', // optional: '/intro-poster.jpg'
  },

  services: [
    {
      title: 'Video Editing',
      body: 'Engaging edits with strong pacing, clean transitions, sound design, and storytelling.',
    },
    {
      title: 'Motion Graphics',
      body: 'Dynamic animations that make information and ideas easier to understand and remember.',
    },
    {
      title: 'Talking Head Videos',
      body: 'Professional editing for personal brands, creators, executives, and businesses.',
    },
    {
      title: 'Brand Animation',
      body: 'Logo animation, typography, visual identity motion, and branded content.',
    },
    {
      title: 'Short-Form Content',
      body: 'Engaging Reels, TikToks, YouTube Shorts, and social media videos.',
    },
    {
      title: 'Visual Storytelling',
      body: 'Combining editing, motion, sound, and composition to communicate ideas clearly.',
    },
  ],

  /** Delete anything you don't actually do. Nothing here is claimed for you. */
  skills: [
    {
      group: 'Video Editing',
      items: ['Premiere Pro', 'DaVinci Resolve'],
    },
    {
      group: 'Motion Design',
      items: ['After Effects', 'Motion Graphics', 'Typography Animation', 'Brand Animation'],
    },
    {
      group: 'Creative',
      items: [
        'Visual Storytelling',
        'Pacing',
        'Composition',
        'Sound Design',
        'Colour',
        'Transitions',
        'Content Creation',
      ],
    },
  ],

  /** Shown in the scrolling tools strip. Remove any you don't use. */
  tools: [
    'Adobe Premiere Pro',
    'Adobe After Effects',
    'DaVinci Resolve',
    'Photoshop',
    'Illustrator',
    'Cinema 4D',
    'AI creative tools',
  ],

  process: [
    {
      step: 'Understand',
      body: 'Understand the message, audience, brand, and objective.',
    },
    {
      step: 'Plan',
      body: 'Develop the visual direction, structure, pacing, and storytelling approach.',
    },
    {
      step: 'Create',
      body: 'Edit footage, build motion graphics, design transitions, sound, and visual elements.',
    },
    {
      step: 'Refine',
      body: 'Polish the details, improve pacing, review feedback, and prepare the final delivery.',
    },
  ],

  principles: {
    heading: 'Creative thinking. Precise execution.',
    items: [
      { title: 'Story first', body: 'Every edit should serve the message.' },
      { title: 'Detail driven', body: 'Small details make a big difference.' },
      { title: 'Brand conscious', body: 'The content should feel consistent with the brand.' },
      {
        title: 'Clear communication',
        body: 'Projects move better when communication is simple and direct.',
      },
    ],
  },
};

/**
 * Testimonials. Empty by default — the section hides itself until you add one.
 * Add entries in this shape:
 *   { name: 'Jane Doe', company: 'Acme', position: 'Head of Marketing',
 *     quote: '…', image: '/testimonials/jane.jpg' }
 */
export type Testimonial = {
  name: string;
  company: string;
  position: string;
  quote: string;
  image?: string;
};

export const testimonials: Testimonial[] = [];
