import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

export default function Services() {
  return (
    <section id="services" className="scroll-mt-20 border-t border-line py-24 md:py-32">
      <div className="shell">
        <p className="tc mb-6">S03 — Services</p>
        <h2 className="display max-w-[14ch] text-[clamp(2.2rem,7vw,5rem)]">
          <Reveal variant="wipe">What I do</Reveal>
        </h2>

        <ul className="mt-14 grid border-t border-line sm:grid-cols-2 lg:grid-cols-3">
          {site.services.map((s, i) => (
            <li
              key={s.title}
              className="group relative border-b border-line py-8 sm:odd:pr-8 sm:even:pl-8 sm:even:border-l lg:odd:pr-0 lg:even:pl-0 lg:even:border-l-0 lg:px-8 lg:[&:nth-child(3n+1)]:pl-0 lg:[&:nth-child(3n)]:pr-0 lg:[&:not(:nth-child(3n))]:border-r">
              <span className="tc text-cool">{String(i + 1).padStart(2, '0')}</span>
              <h3 className="mt-4 text-xl font-semibold tracking-tight transition-colors duration-300 group-hover:text-accent">
                {s.title}
              </h3>
              <p className="mt-3 max-w-[34ch] text-sm leading-relaxed text-muted">{s.body}</p>
              <span className="absolute inset-x-0 bottom-[-1px] h-px origin-left scale-x-0 bg-accent transition-transform duration-500 ease-cut group-hover:scale-x-100" />
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
