import Link from 'next/link';
import { site } from '@/data/site';

export default function Footer() {
  const socials = site.contact.socials.filter((s) => !s.href.startsWith('YOUR_'));

  return (
    <footer className="border-t border-line">
      <div className="shell grid gap-12 py-16 md:grid-cols-[1.4fr_1fr_1fr] md:py-20">
        <div>
          <p className="text-lg font-bold tracking-tight">
            Vxmedia<span className="text-accent">_</span>edit
          </p>
          <p className="mt-2 max-w-xs text-sm text-muted">{site.title}</p>
        </div>

        <nav aria-label="Footer">
          <p className="tc mb-4">Pages</p>
          <ul className="space-y-2">
            {site.nav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="text-sm text-muted transition-colors hover:text-ink"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div>
          <p className="tc mb-4">Elsewhere</p>
          {socials.length > 0 ? (
            <ul className="space-y-2">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-sm text-muted transition-colors hover:text-ink"
                  >
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          ) : (
            <p className="max-w-[24ch] text-sm text-muted">
              Add your links in <code className="text-cool">src/data/site.ts</code>.
            </p>
          )}
        </div>
      </div>

      <div className="shell flex flex-col gap-2 border-t border-line py-6 sm:flex-row sm:items-center sm:justify-between">
        <p className="tc">© 2026 Vxmedia_edit. All rights reserved.</p>
        <p className="tc">{site.availability}</p>
      </div>
    </footer>
  );
}
