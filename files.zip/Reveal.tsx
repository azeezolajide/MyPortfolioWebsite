'use client';

import { motion, useReducedMotion } from 'framer-motion';
import type { ReactNode } from 'react';

type Props = {
  children: ReactNode;
  delay?: number;
  className?: string;
  /** 'up' for blocks, 'wipe' for headline type. */
  variant?: 'up' | 'wipe';
};

export default function Reveal({ children, delay = 0, className, variant = 'up' }: Props) {
  const reduced = useReducedMotion();

  if (reduced) return <div className={className}>{children}</div>;

  if (variant === 'wipe') {
    return (
      <span className={`block overflow-hidden ${className ?? ''}`}>
        <motion.span
          className="block"
          initial={{ y: '105%' }}
          whileInView={{ y: '0%' }}
          viewport={{ once: true, margin: '-12%' }}
          transition={{ duration: 0.8, delay, ease: [0.16, 1, 0.3, 1] }}
        >
          {children}
        </motion.span>
      </span>
    );
  }

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-10%' }}
      transition={{ duration: 0.65, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </motion.div>
  );
}
