/**
 * ─────────────────────────────────────────────────────────────
 *  YOUR PORTFOLIO LIVES HERE.
 *
 *  Every card on /work and every page at /work/<slug> is generated
 *  from this array. To add a project, copy the template block at the
 *  bottom of this file, fill it in, and delete `placeholder: true`.
 *
 *  Thumbnails:
 *    • Leave `thumbnail` empty and a YouTube/Vimeo URL will supply one.
 *    • Or drop an image in /public/work/ and use '/work/my-file.jpg'.
 *
 *  Videos: YouTube, Vimeo, or a direct .mp4 URL all work.
 * ─────────────────────────────────────────────────────────────
 */

export const categories = [
  'All',
  'Motion Graphics',
  'Video Editing',
  'Talking Head',
  'Short Form',
  'Explainer',
  'Brand Animation',
  'AI Video',
  'Social Content',
] as const;

export type Category = Exclude<(typeof categories)[number], 'All'>;

export type Project = {
  title: string;
  slug: string;
  category: Category;
  client?: string;
  year?: string;
  /** Free text, e.g. '1:24' or '00:47'. */
  duration?: string;
  /** Path under /public or a remote image URL. Leave '' to auto-derive. */
  thumbnail?: string;
  /** YouTube / Vimeo / .mp4 URL. */
  video?: string;
  description?: string;
  /** Longer case-study paragraph shown on the project page. */
  approach?: string;
  tools?: string[];
  role?: string;
  /** Plain outcomes only. Don't write numbers you can't stand behind. */
  results?: string[];
  gallery?: string[];
  /** true = an empty slot rendered as a placeholder. Delete when filled in. */
  placeholder?: boolean;
};

export const projects: Project[] = [
  { title: 'Open slot', slug: 'slot-01', category: 'Motion Graphics', placeholder: true },
  { title: 'Open slot', slug: 'slot-02', category: 'Video Editing', placeholder: true },
  { title: 'Open slot', slug: 'slot-03', category: 'Short Form', placeholder: true },
  { title: 'Open slot', slug: 'slot-04', category: 'Talking Head', placeholder: true },
  { title: 'Open slot', slug: 'slot-05', category: 'Brand Animation', placeholder: true },
  { title: 'Open slot', slug: 'slot-06', category: 'Explainer', placeholder: true },
];

/*
──────────────────────────────────────────────────────────────
TEMPLATE — copy this, paste it into the array above, fill it in.
The shape below is a structural example only, not a real project.

{
  title: 'SaaS Product Explainer',
  slug: 'saas-product-explainer',   // becomes /work/saas-product-explainer
  category: 'Motion Graphics',
  client: 'YOUR_CLIENT',
  year: '2026',
  duration: '1:12',
  thumbnail: '',                    // '' = derived from the video URL
  video: 'YOUR_PROJECT_VIDEO',      // e.g. https://youtu.be/xxxxxxxxxxx
  description:
    'A motion-led product video designed to explain a SaaS product in a simple and engaging way.',
  approach:
    'Two or three sentences on the brief, the visual direction you chose, and why.',
  tools: ['After Effects', 'Premiere Pro'],
  role: 'Video Editor / Motion Designer',
  results: ['What the video was used for', 'What it helped the client do'],
  gallery: ['/work/frame-01.jpg', '/work/frame-02.jpg'],
},
──────────────────────────────────────────────────────────────
*/

export const liveProjects = projects.filter((p) => !p.placeholder);

export function getProject(slug: string) {
  return liveProjects.find((p) => p.slug === slug);
}

export function getAdjacent(slug: string) {
  const i = liveProjects.findIndex((p) => p.slug === slug);
  if (i === -1) return { prev: undefined, next: undefined };
  return {
    prev: liveProjects[(i - 1 + liveProjects.length) % liveProjects.length],
    next: liveProjects[(i + 1) % liveProjects.length],
  };
}
