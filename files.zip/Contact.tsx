import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

export default function Contact() {
  const { email, socials } = site.contact;
  const hasEmail = !email.startsWith('YOUR_');
  const links = socials.filter((s) => !s.href.startsWith('YOUR_'));

  return (
    <section id="contact" className="scroll-mt-20 border-t border-line py-28 md:py-40">
      <div className="shell">
        <h2 className="display max-w-[14ch] text-[clamp(2.6rem,9vw,7rem)]">
          <Reveal variant="wipe">Have a project in mind?</Reveal>
        </h2>

        <Reveal delay={0.08}>
          <p className="mt-8 max-w-prose text-lg leading-relaxed text-muted">
            Let’s turn your idea into something people want to watch.
          </p>
        </Reveal>

        <Reveal delay={0.14}>
          <div className="mt-12 flex flex-wrap items-center gap-4">
            <a href={hasEmail ? `mailto:${email}` : '#contact'} className="btn-accent">
              Let’s work together
            </a>
            {hasEmail ? (
              <a
                href={`mailto:${email}`}
                className="text-base text-muted underline-offset-4 transition-colors hover:text-ink hover:underline"
              >
                {email}
              </a>
            ) : (
              <span className="text-sm text-muted">
                Add your address to <code className="text-cool">contact.email</code> in{' '}
                <code className="text-cool">src/data/site.ts</code>.
              </span>
            )}
          </div>
        </Reveal>

        {links.length > 0 && (
          <ul className="mt-16 flex flex-wrap gap-x-10 gap-y-4 border-t border-line pt-8">
            {links.map((s) => (
              <li key={s.label}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="text-base text-muted transition-colors hover:text-accent"
                >
                  {s.label}
                </a>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
