import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

export default function Skills() {
  return (
    <section className="border-t border-line py-24 md:py-32">
      <div className="shell grid gap-12 md:grid-cols-[auto_1fr] md:gap-20">
        <p className="tc md:pt-3">S05 — Skills</p>

        <div className="divide-y divide-line border-y border-line">
          {site.skills.map((group) => (
            <Reveal key={group.group}>
              <div className="grid gap-4 py-8 md:grid-cols-[14rem_1fr]">
                <h3 className="text-lg font-semibold tracking-tight">{group.group}</h3>
                <ul className="flex flex-wrap gap-x-6 gap-y-2">
                  {group.items.map((item) => (
                    <li key={item} className="text-base text-muted">
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
