import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

/** A real sequence, so the numbering and the timeline spine earn their place. */
export default function Process() {
  return (
    <section className="border-t border-line py-24 md:py-32">
      <div className="shell">
        <p className="tc mb-6">S04 — Process</p>
        <h2 className="display max-w-[14ch] text-[clamp(2.2rem,7vw,5rem)]">
          <Reveal variant="wipe">From idea to final cut</Reveal>
        </h2>

        <ol className="relative mt-16 grid gap-10 md:grid-cols-4 md:gap-6">
          <span
            aria-hidden="true"
            className="absolute left-[5px] top-2 hidden h-px w-full bg-line md:block"
          />
          {site.process.map((p, i) => (
            <li key={p.step} className="relative md:pt-10">
              <span
                aria-hidden="true"
                className="absolute left-0 top-0 hidden h-[11px] w-[11px] rotate-45 border border-accent bg-base md:block"
              />
              <Reveal delay={i * 0.06}>
                <p className="tc text-accent">{String(i + 1).padStart(2, '0')}</p>
                <h3 className="mt-3 text-xl font-semibold tracking-tight">{p.step}</h3>
                <p className="mt-3 max-w-[30ch] text-sm leading-relaxed text-muted">{p.body}</p>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
