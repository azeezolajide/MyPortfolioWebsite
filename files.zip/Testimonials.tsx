import Image from 'next/image';
import Reveal from '@/components/Reveal';
import { testimonials } from '@/data/site';

/** Renders nothing until you add a real testimonial in src/data/site.ts. */
export default function Testimonials() {
  if (testimonials.length === 0) return null;

  return (
    <section className="border-t border-line py-24 md:py-32">
      <div className="shell">
        <p className="tc mb-6">S07 — Feedback</p>
        <h2 className="display max-w-[16ch] text-[clamp(2.2rem,7vw,4.5rem)]">
          <Reveal variant="wipe">What clients say</Reveal>
        </h2>

        <div className="mt-14 grid gap-8 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 0.05}>
              <figure className="h-full rounded-lg border border-line p-8">
                <blockquote className="max-w-prose text-base leading-relaxed text-ink">
                  {t.quote}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-4">
                  {t.image && (
                    <Image
                      src={t.image}
                      alt=""
                      width={40}
                      height={40}
                      className="h-10 w-10 rounded-full object-cover"
                    />
                  )}
                  <span className="text-sm">
                    <span className="block font-semibold">{t.name}</span>
                    <span className="block text-muted">
                      {t.position}, {t.company}
                    </span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
