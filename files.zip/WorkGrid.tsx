'use client';

import { useMemo, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { categories, type Project } from '@/data/projects';
import ProjectCard from './ProjectCard';

export default function WorkGrid({ projects }: { projects: Project[] }) {
  const [active, setActive] = useState<string>('All');
  const reduced = useReducedMotion();

  const visible = useMemo(
    () => (active === 'All' ? projects : projects.filter((p) => p.category === active)),
    [active, projects],
  );

  // Only offer filters that actually match something.
  const available = useMemo(
    () => categories.filter((c) => c === 'All' || projects.some((p) => p.category === c)),
    [projects],
  );

  return (
    <div>
      <div role="tablist" aria-label="Filter projects by category" className="flex flex-wrap gap-2">
        {available.map((c) => {
          const isActive = c === active;
          return (
            <button
              key={c}
              role="tab"
              aria-selected={isActive}
              onClick={() => setActive(c)}
              className={`rounded-full border px-4 py-2 text-sm transition duration-300 ease-cut ${
                isActive
                  ? 'border-accent bg-accent text-base'
                  : 'border-line text-muted hover:border-ink hover:text-ink'
              }`}
            >
              {c}
            </button>
          );
        })}
      </div>

      <div
        aria-live="polite"
        className="mt-10 grid gap-x-6 gap-y-12 sm:grid-cols-2 lg:grid-cols-3"
      >
        <AnimatePresence mode="popLayout" initial={false}>
          {visible.map((project) => (
            <motion.div
              key={project.slug}
              layout={!reduced}
              initial={reduced ? false : { opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={reduced ? undefined : { opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            >
              <ProjectCard project={project} />
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {visible.length === 0 && (
        <p className="mt-12 text-sm text-muted">Nothing in this category yet.</p>
      )}
    </div>
  );
}
