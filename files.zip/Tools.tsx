import { site } from '@/data/site';

/** Marquee is duplicated once so the loop is seamless; hidden from AT. */
export default function Tools() {
  const row = [...site.tools, ...site.tools];

  return (
    <section className="overflow-hidden border-t border-line py-10">
      <div className="flex w-max animate-marquee gap-12 pr-12" aria-hidden="true">
        {row.map((tool, i) => (
          <span key={`${tool}-${i}`} className="flex items-center gap-12 whitespace-nowrap">
            <span className="text-2xl font-semibold tracking-tight text-muted md:text-3xl">
              {tool}
            </span>
            <span className="h-1 w-1 rounded-full bg-accent" />
          </span>
        ))}
      </div>
      <p className="sr-only">Tools I work with: {site.tools.join(', ')}.</p>
    </section>
  );
}
