import Reveal from '@/components/Reveal';
import VideoEmbed from '@/components/VideoEmbed';
import { site } from '@/data/site';

export default function IntroVideo() {
  return (
    <section className="border-t border-line py-24 md:py-32">
      <div className="shell">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="display text-[clamp(2rem,5.4vw,4rem)]">
            <Reveal variant="wipe">{site.introVideo.heading}</Reveal>
          </h2>
          <Reveal delay={0.08}>
            <p className="mx-auto mt-6 max-w-prose text-base leading-relaxed text-muted">
              {site.introVideo.body}
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.1} className="mx-auto mt-14 max-w-4xl">
          <VideoEmbed
            url={site.introVideo.url}
            poster={site.introVideo.poster}
            title="Vxmedia_edit introduction"
            emptyHint="Paste your introduction video URL into introVideo.url in src/data/site.ts."
          />
        </Reveal>
      </div>
    </section>
  );
}
