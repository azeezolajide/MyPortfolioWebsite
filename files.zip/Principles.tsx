import Reveal from '@/components/Reveal';
import { site } from '@/data/site';

export default function Principles() {
  return (
    <section className="border-t border-line py-24 md:py-32">
      <div className="shell">
        <p className="tc mb-6">S06 — How I work</p>
        <h2 className="display max-w-[16ch] text-[clamp(2.2rem,7vw,5rem)]">
          <Reveal variant="wipe">{site.principles.heading}</Reveal>
        </h2>

        <div className="mt-14 grid gap-px bg-line sm:grid-cols-2">
          {site.principles.items.map((item, i) => (
            <Reveal key={item.title} delay={i * 0.05}>
              <div className="h-full bg-base p-8">
                <h3 className="text-lg font-semibold tracking-tight">{item.title}</h3>
                <p className="mt-3 max-w-[38ch] text-sm leading-relaxed text-muted">{item.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
