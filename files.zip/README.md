# Vxmedia_edit

Portfolio site for **Vxmedia_edit** — Video Editor & Motion Graphics Designer.
Next.js 14 (App Router) · TypeScript · Tailwind CSS · Framer Motion. Built to deploy on Vercel.

---

## Run it locally

```bash
npm install
npm run dev          # http://localhost:3000
```

Production check:

```bash
npm run build
npm start
```

No environment variables are required. `NEXT_PUBLIC_SITE_URL` is optional and
only affects canonical URLs, the sitemap, and social cards.

---

## Where to edit things

Two files hold all your content. You never need to open a component.

### `src/data/site.ts`

| What | Field |
| --- | --- |
| Email | `contact.email` |
| LinkedIn / Instagram / X / YouTube | `contact.socials` |
| Hero headline and intro line | `hero` |
| Availability badge | `availability` |
| About heading and paragraphs | `about` |
| Introduction video URL | `introVideo.url` |
| Six service cards | `services` |
| Skills groups | `skills` |
| Tools strip | `tools` |
| Process steps | `process` |
| "How I work" points | `principles` |
| Page title, meta description, keywords | `seo` |
| Testimonials | `testimonials` (bottom of the file) |

Anything written as `YOUR_EMAIL`, `YOUR_LINKEDIN`, `YOUR_INTRO_VIDEO` etc. is a
placeholder. The site detects them and either hides that element or shows a
quiet note instead of printing a broken link.

### `src/data/projects.ts`

Your portfolio. The array ships with six empty slots so you can see the layout;
replace them with real work.

1. Copy the commented `TEMPLATE` block at the bottom of the file.
2. Paste it into the `projects` array.
3. Fill it in and make sure `slug` is unique — it becomes the URL
   (`/work/your-slug`).
4. Delete any leftover `placeholder: true` entries.

A project supports: `title`, `slug`, `category`, `client`, `year`, `duration`,
`thumbnail`, `video`, `description`, `approach`, `tools`, `role`, `results`,
`gallery`.

---

## Videos and images

**Videos** — paste any of these into `video` (or `introVideo.url`):

- YouTube: `https://youtu.be/ID`, `https://youtube.com/watch?v=ID`, or a Shorts URL
- Vimeo: `https://vimeo.com/123456789`
- Direct file: `https://…/clip.mp4` (also `.webm`, `.mov`)

Nothing loads until a visitor presses play — you get a still frame and a play
button, so a page full of projects stays fast. YouTube is embedded through
`youtube-nocookie.com`.

**Thumbnails** — leave `thumbnail: ''` and the YouTube/Vimeo still is used
automatically. To use your own, drop the file in `public/work/` and write
`thumbnail: '/work/my-file.jpg'`. Use 16:9 images, roughly 1600×900.

**Social card** — a card is generated automatically. To use your own, put a
1200×630 image in `public/` and set `seo.ogImage` to `'/og.jpg'`.

**Favicon** — replace `public/favicon.svg`.

Remote image hosts are allow-listed in `next.config.mjs`. If you use a different
image CDN, add its hostname there.

---

## Adding a category

Add the name to the `categories` array in `src/data/projects.ts`. Filters only
appear for categories that actually contain a project, so nothing looks empty.

---

## Project structure

```
src/
  app/
    layout.tsx            fonts, metadata, nav, footer, playhead
    page.tsx              homepage (composes the sections)
    globals.css           tokens, base styles, reduced-motion rules
    not-found.tsx         404
    robots.ts             generates /robots.txt
    sitemap.ts            generates /sitemap.xml
    opengraph-image.tsx   generated social card
    work/page.tsx         /work — full filterable grid
    work/[slug]/page.tsx  /work/<slug> — case study page
  components/
    Nav.tsx               sticky nav + mobile menu
    Footer.tsx
    Playhead.tsx          scroll-linked scrub bar and timecode
    Reveal.tsx            scroll reveal, respects reduced motion
    VideoEmbed.tsx        YouTube / Vimeo / MP4, click-to-load
    ProjectCard.tsx
    WorkGrid.tsx          category filtering
  sections/               the homepage sections, in page order
  data/
    site.ts               ← your details
    projects.ts           ← your portfolio
  lib/video.ts            URL parsing and thumbnail fallbacks
public/                   favicon, your images
```

---

## Design notes

- Near-black `#08090A` base, warm white type, one accent: tungsten amber
  `#FFB627`, with a cold steel `#7E93A6` for secondary type — the orange/teal
  grade, borrowed from colour work rather than from a UI kit.
- Archivo for everything, IBM Plex Mono reserved for real timecode and metadata.
- One signature motion idea: the page behaves like a sequence. A scrub bar and
  running timecode sit at the bottom of the viewport and track scroll position.
- Every animation is behind `prefers-reduced-motion`. Focus rings are visible,
  the nav traps Escape, and there's a skip link.

To change the accent colour, edit `tailwind.config.ts` — it's one value.

---

## Deploy to Vercel

### Option 1 — GitHub (recommended)

1. Create a new repository on GitHub.
2. Push the project:

   ```bash
   git init
   git add .
   git commit -m "Vxmedia_edit portfolio"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/vxmedia-edit.git
   git push -u origin main
   ```

3. Go to [vercel.com/new](https://vercel.com/new) and sign in with GitHub.
4. Import the repository. Vercel detects Next.js — leave the build settings alone.
5. Optionally add `NEXT_PUBLIC_SITE_URL` under Environment Variables.
6. Click **Deploy**.
7. Add a custom domain later under Project → Settings → Domains.

Every push to `main` redeploys automatically.

### Option 2 — Vercel CLI

```bash
npm i -g vercel
vercel login
vercel          # preview deployment
vercel --prod   # production deployment
```

---

## Environment variables

| Name | Required | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | No | Canonical URL used by the sitemap and social cards. Defaults to the Vercel URL. |
