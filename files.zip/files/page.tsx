import Hero from '@/sections/Hero';
import About from '@/sections/About';
import IntroVideo from '@/sections/IntroVideo';
import Work from '@/sections/Work';
import Services from '@/sections/Services';
import Process from '@/sections/Process';
import Skills from '@/sections/Skills';
import Tools from '@/sections/Tools';
import Principles from '@/sections/Principles';
import Testimonials from '@/sections/Testimonials';
import Contact from '@/sections/Contact';

export default function HomePage() {
  return (
    <>
      <Hero />
      <About />
      <IntroVideo />
      <Work />
      <Services />
      <Process />
      <Skills />
      <Tools />
      <Principles />
      <Testimonials />
      <Contact />
    </>
  );
}
