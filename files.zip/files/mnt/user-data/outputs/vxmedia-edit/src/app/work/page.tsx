import type { Metadata } from 'next';
import Reveal from '@/components/Reveal';
import WorkGrid from '@/components/WorkGrid';
import { projects } from '@/data/projects';

export const metadata: Metadata = {
  title: 'Work',
  description:
    'Video editing, motion graphics, brand animation and visual storytelling projects by Vxmedia_edit.',
  alternates: { canonical: '/work' },
};

export default function WorkPage() {
  return (
    <section className="pb-28 pt-36 md:pt-44">
      <div className="shell">
        <h1 className="display max-w-[14ch] text-[clamp(2.6rem,9vw,7rem)]">
          <Reveal variant="wipe">Selected work</Reveal>
        </h1>
        <Reveal delay={0.08}>
          <p className="mt-8 max-w-prose text-base leading-relaxed text-muted">
            A selection of video editing, motion graphics, brand animation, and visual storytelling
            projects. Filter by category to narrow things down.
          </p>
        </Reveal>

        <div className="mt-16">
          <WorkGrid projects={projects} />
        </div>
      </div>
    </section>
  );
}
