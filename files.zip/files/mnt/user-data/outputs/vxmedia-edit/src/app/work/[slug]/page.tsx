import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import Reveal from '@/components/Reveal';
import VideoEmbed from '@/components/VideoEmbed';
import { getAdjacent, getProject, liveProjects } from '@/data/projects';
import { posterFor } from '@/lib/video';

type Params = { params: { slug: string } };

export function generateStaticParams() {
  return liveProjects.map((p) => ({ slug: p.slug }));
}

export function generateMetadata({ params }: Params): Metadata {
  const project = getProject(params.slug);
  if (!project) return { title: 'Project not found' };

  const still = posterFor(project.thumbnail, project.video);

  return {
    title: project.title,
    description: project.description,
    alternates: { canonical: `/work/${project.slug}` },
    openGraph: {
      title: project.title,
      description: project.description,
      images: still ? [still] : undefined,
    },
  };
}

export default function ProjectPage({ params }: Params) {
  const project = getProject(params.slug);
  if (!project) notFound();

  const { prev, next } = getAdjacent(project.slug);
  const meta = [
    { label: 'Client', value: project.client },
    { label: 'Year', value: project.year },
    { label: 'Role', value: project.role },
    { label: 'Duration', value: project.duration },
    { label: 'Category', value: project.category },
  ].filter((m) => m.value && !m.value.startsWith('YOUR_'));

  return (
    <article className="pb-28 pt-36 md:pt-44">
      <div className="shell">
        <Link href="/work" className="text-sm text-muted transition-colors hover:text-accent">
          ← All work
        </Link>

        <h1 className="display mt-8 max-w-[16ch] text-[clamp(2.4rem,8vw,6rem)]">
          <Reveal variant="wipe">{project.title}</Reveal>
        </h1>

        {project.description && (
          <Reveal delay={0.08}>
            <p className="mt-8 max-w-prose text-lg leading-relaxed text-muted">
              {project.description}
            </p>
          </Reveal>
        )}

        <Reveal delay={0.1} className="mt-14">
          <VideoEmbed url={project.video} poster={project.thumbnail} title={project.title} />
        </Reveal>

        {meta.length > 0 && (
          <dl className="mt-14 grid gap-8 border-y border-line py-8 sm:grid-cols-3 lg:grid-cols-5">
            {meta.map((m) => (
              <div key={m.label}>
                <dt className="tc">{m.label}</dt>
                <dd className="mt-2 text-sm">{m.value}</dd>
              </div>
            ))}
          </dl>
        )}

        <div className="mt-16 grid gap-12 md:grid-cols-[1fr_18rem] md:gap-20">
          <div className="space-y-10">
            {project.approach && (
              <Reveal>
                <h2 className="text-xl font-semibold tracking-tight">Creative approach</h2>
                <p className="mt-4 max-w-prose text-base leading-relaxed text-muted">
                  {project.approach}
                </p>
              </Reveal>
            )}

            {project.results && project.results.length > 0 && (
              <Reveal>
                <h2 className="text-xl font-semibold tracking-tight">Outcome</h2>
                <ul className="mt-4 max-w-prose space-y-2 text-base leading-relaxed text-muted">
                  {project.results.map((r) => (
                    <li key={r} className="flex gap-3">
                      <span className="mt-[0.6em] h-1 w-1 shrink-0 rounded-full bg-accent" />
                      {r}
                    </li>
                  ))}
                </ul>
              </Reveal>
            )}
          </div>

          {project.tools && project.tools.length > 0 && (
            <aside>
              <h2 className="tc">Tools</h2>
              <ul className="mt-4 space-y-2">
                {project.tools.map((t) => (
                  <li key={t} className="text-sm text-muted">
                    {t}
                  </li>
                ))}
              </ul>
            </aside>
          )}
        </div>

        {project.gallery && project.gallery.length > 0 && (
          <div className="mt-20 grid gap-6 sm:grid-cols-2">
            {project.gallery.map((src, i) => (
              <Reveal key={src} delay={i * 0.05}>
                <Image
                  src={src}
                  alt={`${project.title} — frame ${i + 1}`}
                  width={1280}
                  height={720}
                  loading="lazy"
                  className="w-full rounded-lg border border-line object-cover"
                />
              </Reveal>
            ))}
          </div>
        )}

        {prev && next && liveProjects.length > 1 && (
          <nav
            aria-label="Project navigation"
            className="mt-24 flex items-center justify-between gap-6 border-t border-line pt-8"
          >
            <Link href={`/work/${prev.slug}`} className="group max-w-[45%]">
              <span className="tc">Previous</span>
              <span className="mt-2 block text-base font-semibold transition-colors group-hover:text-accent">
                {prev.title}
              </span>
            </Link>
            <Link href={`/work/${next.slug}`} className="group max-w-[45%] text-right">
              <span className="tc">Next</span>
              <span className="mt-2 block text-base font-semibold transition-colors group-hover:text-accent">
                {next.title}
              </span>
            </Link>
          </nav>
        )}
      </div>
    </article>
  );
}
