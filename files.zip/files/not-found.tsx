import Link from 'next/link';

export default function NotFound() {
  return (
    <section className="shell flex min-h-[70svh] flex-col justify-center py-32">
      <p className="tc mb-6">Offline media</p>
      <h1 className="display text-[clamp(2.4rem,8vw,6rem)]">This clip isn’t here</h1>
      <p className="mt-6 max-w-prose text-base leading-relaxed text-muted">
        The page you asked for doesn’t exist, or the project has been renamed.
      </p>
      <div className="mt-10 flex flex-wrap gap-3">
        <Link href="/" className="btn-accent">
          Back to home
        </Link>
        <Link href="/work" className="btn-ghost">
          Browse the work
        </Link>
      </div>
    </section>
  );
}
