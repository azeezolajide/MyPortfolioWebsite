export type VideoSource =
  | { kind: 'youtube'; id: string; embed: string }
  | { kind: 'vimeo'; id: string; embed: string }
  | { kind: 'file'; src: string }
  | { kind: 'none' };

const YT = /(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([\w-]{6,})/;
const VIMEO = /vimeo\.com\/(?:video\/)?(\d+)/;

/** Turns any supported URL into something we can embed. Never throws. */
export function parseVideo(url?: string): VideoSource {
  if (!url || url.startsWith('YOUR_')) return { kind: 'none' };

  const yt = url.match(YT);
  if (yt) {
    return {
      kind: 'youtube',
      id: yt[1],
      embed: `https://www.youtube-nocookie.com/embed/${yt[1]}?rel=0&modestbranding=1`,
    };
  }

  const vm = url.match(VIMEO);
  if (vm) {
    return { kind: 'vimeo', id: vm[1], embed: `https://player.vimeo.com/video/${vm[1]}` };
  }

  if (/\.(mp4|webm|mov)(\?.*)?$/i.test(url)) return { kind: 'file', src: url };

  return { kind: 'none' };
}

/** Falls back to the platform's own thumbnail when no image is supplied. */
export function posterFor(thumbnail?: string, videoUrl?: string): string | null {
  if (thumbnail && !thumbnail.startsWith('YOUR_')) return thumbnail;

  const v = parseVideo(videoUrl);
  if (v.kind === 'youtube') return `https://i.ytimg.com/vi/${v.id}/maxresdefault.jpg`;
  if (v.kind === 'vimeo') return `https://vumbnail.com/${v.id}.jpg`;
  return null;
}
