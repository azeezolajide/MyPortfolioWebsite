import type { MetadataRoute } from 'next';
import { site } from '@/data/site';
import { liveProjects } from '@/data/projects';

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();

  return [
    { url: site.url, lastModified: now, priority: 1 },
    { url: `${site.url}/work`, lastModified: now, priority: 0.8 },
    ...liveProjects.map((p) => ({
      url: `${site.url}/work/${p.slug}`,
      lastModified: now,
      priority: 0.6,
    })),
  ];
}
