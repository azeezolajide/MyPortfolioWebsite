import { ImageResponse } from 'next/og';
import { site } from '@/data/site';

export const runtime = 'edge';
export const alt = site.seo.title;
export const size = { width: 1200, height: 630 };
export const contentType = 'image/png';

export default function OgImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'flex-end',
          background: '#08090A',
          padding: 72,
          color: '#F2F1EE',
          fontFamily: 'sans-serif',
        }}
      >
        <div style={{ display: 'flex', fontSize: 26, color: '#FFB627', letterSpacing: 2 }}>
          VXMEDIA_EDIT
        </div>
        <div
          style={{
            display: 'flex',
            flexDirection: 'column',
            marginTop: 24,
            fontSize: 112,
            fontWeight: 800,
            lineHeight: 1,
            letterSpacing: -4,
            textTransform: 'uppercase',
          }}
        >
          <span>Video Editor</span>
          <span style={{ color: '#7E93A6' }}>&amp; Motion Designer</span>
        </div>
        <div style={{ display: 'flex', marginTop: 32, fontSize: 28, color: '#8C9298' }}>
          Editing, motion graphics, and visual storytelling.
        </div>
      </div>
    ),
    size,
  );
}
